# Plano de Implementação - Correção da Sobreposição de Letras Fantasmas no Terminal

Analisando as capturas de tela e o comportamento do terminal, identificamos que o componente nativo `<Prompt>` possui um bug de renderização no buffer do terminal: quando a lista ou valor de `placeholders` é atualizado dinamicamente enquanto o usuário fala, o terminal não limpa o desenho anterior da tela. Isso faz com que a nova transcrição seja desenhada diretamente em cima da dica padrão ("Escreva testes unitários...") ou da transcrição parcial anterior, gerando um texto embaralhado e sobreposto.

## Proposta de Solução

Para corrigir esse problema de sobreposição sem precisar alterar a engine nativa do terminal (fechada no executável `opencode.exe`), usaremos uma técnica reativa no SolidJS para **forçar a destruição e recriação** do componente `<Prompt>` toda vez que o texto fantasma (`stt.ghost_text`) mudar.

Ao recriar o componente do zero, o terminal limpa o buffer de desenho daquela área, eliminando qualquer rastro de placeholders antigos ou sobreposições.

## Mudanças Propostas

### TUI Component (`tui.tsx`)

#### [MODIFY] [tui.tsx](file:///C:/Users/migue/.cache/opencode/packages/@renjfk/opencode-voice@latest/node_modules/@renjfk/opencode-voice/tui.tsx)

Usar uma estrutura condicional reativa para remontar o `<Prompt>` do zero sempre que o estado de gravação ou o texto fantasma mudarem.

```tsx
// Exemplo de estrutura de recriação forçada no home_prompt e session_prompt:
home_prompt(ctx, value) {
  const Prompt = api.ui.Prompt;
  const Slot = api.ui.Slot;
  const isRecording = () => api.kv.get("stt.recording", false);
  const ghostText = () => api.kv.get("stt.ghost_text", "");
  
  // Criamos uma chave única combinando o estado de gravação e o texto atual
  const promptKey = () => `${isRecording()}-${ghostText()}`;

  // Ao usar um componente dinâmico ou condicional baseado em promptKey(), 
  // forçamos o SolidJS a destruir o Prompt anterior e renderizar um novo limpo.
  return (
    <box>
      {/* A avaliação dinâmica baseada em função força o re-mount completo */}
      {(() => {
        const rec = isRecording();
        const txt = ghostText();
        const placeholder = rec ? [txt || "Fale agora..."] : ["Pergunte qualquer coisa...", "Escreva testes unitários para a classe", "Explique como funciona este método"];
        const shellPlaceholder = rec ? [txt || "Fale agora..."] : ["git status", "docker compose up", "npm run test"];
        
        return (
          <Prompt
            key={promptKey()} // Chave para identificação de mudança
            workspaceID={value.workspace_id}
            right={
              <box flexDirection="row" gap={1}>
                <Slot name="home_prompt_right" workspace_id={value.workspace_id} />
              </box>
            }
            placeholders={{ normal: placeholder, shell: shellPlaceholder }}
          />
        );
      })()}
    </box>
  );
}
```

## Plano de Verificação

### Teste Manual
1. Abrir o terminal do OpenCode.
2. Pressione **F9** para iniciar a gravação. O placeholder padrão deve sumir instantaneamente, exibindo apenas `"Fale agora..."`.
3. Começar a falar. Conforme a transcrição avança, o texto fantasma deve atualizar de forma limpa, sem reter nenhuma letra do placeholder anterior ou sobrepor palavras antigas.
