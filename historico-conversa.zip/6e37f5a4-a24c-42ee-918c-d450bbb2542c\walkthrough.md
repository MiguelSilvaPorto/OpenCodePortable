# Walkthrough - Correção da Sobreposição de Placeholder

Implementamos uma solução elegante para o bug de sobreposição de placeholders no terminal.

## Mudanças Realizadas

### TUI Plugin (`tui.tsx`)
* **Restauração do Prompt Nativo**: Restauramos a renderização do componente `<Prompt>` nativo em [tui.tsx](file:///C:/Users/migue/.cache/opencode/packages/@renjfk/opencode-voice@latest/node_modules/@renjfk/opencode-voice/tui.tsx) para preservar completamente a identidade visual (bordas, fundo e comportamento funcional) do chat do OpenCode.
* **Atualização Reativa de Placeholders**: Em vez de recriar ou substituir o Prompt por um `<box>` (o que causava o sumiço do prompt e impedia a inserção final do texto no editor), passamos as funções reativas diretamente na propriedade `placeholders`.
* **Fluxo de Escrita Garantido**: Como o `<Prompt>` permanece montado durante todo o ciclo de gravação, a chamada final `appendPrompt` consegue injetar a transcrição normalizada com sucesso no editor do terminal no fim da gravação, mantendo o funcionamento nativo e a estética intocada.

## Resultados
* Não há mais sobreposição de textos do placeholder antigo com o novo texto fantasma.
* A transcrição em tempo real aparece de forma legível e sem misturar com textos anteriores.
